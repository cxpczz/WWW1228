Currently, only PHP, CSS and HTML / XHTML are supported.

Installation:
Import these into phpDesigner by entering the preferences dialog (Tools > Preferences or CTRL+E) then select Editor > Syntax Highlighters.
Select PHP from the highlighter dropdown and click the import button.
Select syntax_php2.dat and then do the same for the other files.

You will also manually need to set the following colours:

In the Editor section:
Background: Red: 57, Green: 57, Blue: 57
Active Line: whatever you want, I use the same as the background
Set the Editor Font: I recommend Bitstream Vera Sans Mono, Bold, Size 11 (http://www.gnome.org/fonts/)

Editor > Syntax Highlighters > Intelligent Highlighting:
Background: Red: 57, Green: 57, Blue: 57
Foreground: Background: Red: 255, Green: 255, Blue: 255

