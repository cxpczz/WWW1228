package com.chenxp.stru.adapter;

//抽象灯光类（抽象适配者2）
public abstract class Lamp {
	
	//待适配的方法（接口）
	public abstract void twinkle();

}
