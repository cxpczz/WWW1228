package com.chenxp.creation.simplefactory;

public class SubOperation extends Operation {

	@Override
	public int getResult() {
		
		return numberA - numberB;
	}

}
