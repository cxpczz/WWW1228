package com.chenxp.stru.adapter;

//抽象声音类（抽象适配者1）
public abstract class Sound {
	
	//待适配的方法（接口）
	public abstract void phonate();

}
