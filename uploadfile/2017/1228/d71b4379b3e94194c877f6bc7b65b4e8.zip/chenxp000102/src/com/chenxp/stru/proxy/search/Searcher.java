package com.chenxp.stru.proxy.search;

//抽象主题（保证了代理对象和被代理对象必须实现的接口）
public interface Searcher {
	
	public String search(String userId, String keyword);

}
