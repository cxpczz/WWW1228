package com.chenxp.stru.adapter;

import org.apache.log4j.Logger;

//适配器类
public class CarAdapter extends Car {

	
	Logger logger  = Logger.getLogger(CarAdapter.class);
	//适配者1（抽象）
	Sound sound;
	//适配者2（抽象）
	Lamp lamp;

	
	//构造方法(给属性赋值，生成对象）
	public CarAdapter(Sound sound, Lamp lamp){
		this.sound = sound;
		this.lamp = lamp;	
	}
	
	@Override
	public void move() {
		
		logger.info("陈晓平的玩具汽车开始启动了！");
		
		//调用第一个适配者的待适配方法
		sound.phonate();
		
		//调用第二个适配者的待适配方法
		lamp.twinkle();
	}

}
