package com.chenxp.stru.adapter;

import org.apache.log4j.Logger;

//具体声音类（具体适配者1）
public class ConcreteSound extends Sound {

	Logger logger = Logger.getLogger(ConcreteSound.class);
	
	//具体的待适配的方法（接口）
	@Override
	public void phonate() {
		
		logger.info("陈晓平的声音提示装置正在工作中！");	

	}

}
