package com.chenxp.stru.adapter;

//抽象目标
public abstract class Car {
	
	//抽象接口（限定适配器必须有的接口）
	public abstract void move();
	
	

}
