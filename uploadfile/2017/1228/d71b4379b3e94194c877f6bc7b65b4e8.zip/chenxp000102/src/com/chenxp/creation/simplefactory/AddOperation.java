package com.chenxp.creation.simplefactory;

public class AddOperation extends Operation {

	@Override
	public int getResult() {
		
		return numberA + numberB;
	}

}
