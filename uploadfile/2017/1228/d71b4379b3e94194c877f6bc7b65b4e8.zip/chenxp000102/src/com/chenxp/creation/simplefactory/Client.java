package com.chenxp.creation.simplefactory;

import org.apache.log4j.Logger;
import org.junit.Test;

public class Client {

	int result;
	
	Logger logger = Logger.getLogger(Client.class);

	@Test
	public void test1() {

		Operation op1 = Calculator.creatOperation('+');
		
		op1.setNumberA(20);
		op1.setNumberB(10);
		
		result = op1.getResult();
		
		logger.info("陈晓平的加法对象产品测试：20+10 = ");
		logger.info(result);
		
		

	}
	
	@Test
	public void test2() {

		Operation op1 = Calculator.creatOperation('-');
		
		op1.setNumberA(20);
		op1.setNumberB(10);
		
		result = op1.getResult();
		
		logger.info("陈晓平的减法对象产品测试：20-10 = ");
		logger.info(result);

	}

}
