package com.chenxp.creation.simplefactory;

public abstract class Operation {
	
	int numberA = 0;
	int numberB = 0;
	
	abstract int getResult();

	public int getNumberA() {
		return numberA;
	}

	public void setNumberA(int numberA) {
		this.numberA = numberA;
	}

	public int getNumberB() {
		return numberB;
	}

	public void setNumberB(int numberB) {
		this.numberB = numberB;
	}
	
	

}
