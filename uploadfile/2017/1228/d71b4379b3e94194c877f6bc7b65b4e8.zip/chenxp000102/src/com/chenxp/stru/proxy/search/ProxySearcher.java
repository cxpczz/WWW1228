package com.chenxp.stru.proxy.search;

import org.apache.log4j.Logger;


//查询代理对象
public class ProxySearcher implements Searcher {

	Logger logger = Logger.getLogger(ProxySearcher.class);
	
	private Searcher searcher = new RealSearcher();
	//代理方法（接口）
	
	//preRequest
	public boolean validate(String userId, String keyword){
		if(userId == "陈晓平" && keyword == "20151444201")
			return true;
		else 
			return false;
	}
	
	
	//postRequest
	public void log(String userId){
		
		logger.info("用户：" + userId + "进行查询！");		
		
	}
	
	
	@Override
	public String search(String userId, String keyword) {
		
		String result;
		
		//preRequest(校验）
		if(validate( userId,  keyword)){
			
			//request（通过）
			result = searcher.search(userId, keyword);
			
		}
		
		else 
			result = "用户未授权！";
		
		//postRequest
		log(userId);
		
		
		return result;
	}

}
