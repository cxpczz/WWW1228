package com.chenxp.stru.adapter;

import org.junit.Test;

public class Client {
	
	//抽象的适配者
	Sound sound;
	Lamp lamp;
	
	//抽象目标
	Car car;
	
	
	@Test
	public void test(){
		
		//生成具体适配者，赋值给抽象适配者（里氏代换）
		sound = new ConcreteSound();
		lamp = new ConcreteLamp();
		
		//生成适配器对象（里氏代换）
		car = new CarAdapter(sound,lamp);
		
		//调用适配器的方法
		car.move();
		
	}

}
