package com.chenxp.creation.simplefactory;

//简单工厂模式中的工厂类
public class Calculator {
	
	
	//工厂方法，返回产品对象（根据不同参数，返回不同产品对象）
	public static Operation creatOperation(char operator){
		
		//抽象产品
		Operation op = null;
		
		//根据参数不同，生产不同产品
		switch (operator){
		case '+':
			op = new AddOperation();
			break;
		case '-':
			op = new SubOperation();
			break;
		}		
		return op;
	}
}
