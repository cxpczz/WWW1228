package com.chenxp.stru.adapter;

import org.apache.log4j.Logger;

//具体灯光类（具体适配者2）
public class ConcreteLamp extends Lamp {

	Logger logger = Logger.getLogger(ConcreteLamp.class);
	
	//具体的待适配方法（接口）
	@Override
	public void twinkle() {
		
		logger.info("陈晓平的灯光显示装置正在工作中！");	

	}

}
