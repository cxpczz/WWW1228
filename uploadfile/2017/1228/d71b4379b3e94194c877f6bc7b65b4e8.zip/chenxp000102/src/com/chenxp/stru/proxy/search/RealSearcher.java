package com.chenxp.stru.proxy.search;

import org.apache.log4j.Logger;

//具体的被代理对象
public class RealSearcher implements Searcher {

	Logger logger = Logger.getLogger(RealSearcher.class);
	
	//被代理方法
	@Override
	public String search(String userId,String keyword) {
		    
		logger.info("陈晓平的查询模块正在工作！查询者是：" + userId + "其密码是" + keyword);
		return "Search Reult";
	}

}
