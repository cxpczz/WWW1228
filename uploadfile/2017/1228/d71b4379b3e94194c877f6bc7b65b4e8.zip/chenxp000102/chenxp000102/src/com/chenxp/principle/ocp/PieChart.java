package com.chenxp.principle.ocp;

import org.apache.log4j.Logger;

public class PieChart implements IChart {

	//记日志
	Logger logger = Logger.getLogger(PieChart.class);
	
	@Override
	public void diplay() {
		
		logger.info("正在输出陈晓平的饼形图！");		

	}

}
