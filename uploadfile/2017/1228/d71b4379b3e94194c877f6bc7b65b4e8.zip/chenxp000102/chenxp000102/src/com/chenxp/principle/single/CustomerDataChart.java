package com.chenxp.principle.single;

import org.apache.log4j.Logger;
import org.junit.Test;

public class CustomerDataChart {
	
	
	Logger logger = Logger.getLogger(CustomerDataChart.class);
	
	private CustomerDAO dao = new CustomerDAO();
	
	
	public void createChart() {
		logger.info("正在创建图表");
	}

	@Test
	public void displayChart() {

		// 1.第一步创建图表；
		createChart();
		// 2.获取数据
		dao.findCustomers();
		// 3.在图表上显示数据
		logger.info("正在显示图表");
		
		long t = System.currentTimeMillis();
		
		long a = t%11;
		
		logger.info("a:===" + a);
	}
	
	


}
