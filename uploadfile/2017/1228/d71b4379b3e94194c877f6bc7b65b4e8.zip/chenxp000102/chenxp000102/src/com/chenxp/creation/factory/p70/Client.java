package com.chenxp.creation.factory.p70;

import org.dom4j.DocumentException;
import org.junit.Test;

import com.chenxp.util.XMLUtil;

public class Client {
	
	//声明一个抽象工厂
	IConvertorCreator iConvertorCreator ;
	//声明一个抽象产品
	IConvertor iConvertor;
	
	//XML工具类
	XMLUtil xMLUtil = new XMLUtil();
	
	
	//得到具体工厂
	//@Test
	public void testFactory(){
		
		//得到（TXT转换工具生产）工厂
		iConvertorCreator = new TXTConvertorCreator();
		
		//通过其工厂方法得到相应的产品
		iConvertor = iConvertorCreator.getConvetor();
		
		//相应的产品（TXT转换工具）开始工作
		iConvertor.transform();
		
	}
	
	//@Test
	public void testFactoryByXML() throws InstantiationException, IllegalAccessException, ClassNotFoundException, DocumentException{
		
		//得到（TXT转换工具生产）工厂
		iConvertorCreator = (IConvertorCreator) xMLUtil.getObject("src/ConvertorCreator.xml");
		
		//通过其工厂方法得到相应的产品
		iConvertor = iConvertorCreator.getConvetor();
		
		//相应的产品（TXT转换工具）开始工作
		iConvertor.transform();
		
	}
	
	


}
