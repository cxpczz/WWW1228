package com.chenxp.principle.single;

import org.apache.log4j.Logger;

public class CustomerDAO {
	
	Logger logger = Logger.getLogger(CustomerDAO.class);
			
	private DBUtil util = new DBUtil();
	
	
	public void findCustomers() {

		// 1.连接数据库
		util.getConnection();

		// 2.通过Sql语句查询数据库
		logger.info("正在通过数据库查找客户");
	}

}
