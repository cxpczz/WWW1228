package com.chenxp.principle.ocp;

public interface IChart {
	
	//默认是抽象、公有的
	void diplay();

}
