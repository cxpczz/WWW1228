package com.chenxp.creation.factory.p70;

//产品（转换工具）的抽象
public interface IConvertor {
	
	//工具的用途：转换（抽象）
	void transform();

}
