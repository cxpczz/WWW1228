package com.chenxp.principle.single;

import org.apache.log4j.Logger;

public class DBUtil {
	
	Logger logger = Logger.getLogger(DBUtil.class);
	
	public void getConnection() {

		logger.info("正在获取数据库连接");

	}

}
