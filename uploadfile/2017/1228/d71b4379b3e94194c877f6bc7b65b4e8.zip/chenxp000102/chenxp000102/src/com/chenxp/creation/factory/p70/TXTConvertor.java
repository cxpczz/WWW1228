package com.chenxp.creation.factory.p70;

import org.apache.log4j.Logger;

//TXT文件转换工具（具体产品）
public class TXTConvertor implements IConvertor {

	Logger logger = Logger.getLogger(TXTConvertor.class);
	
	//当前产品（TXT文件转化工具）正在干活
	@Override
	public void transform() {
		
		logger.info("陈晓平的TXT转换工具正在工作中！");

	}

}
