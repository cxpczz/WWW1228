package com.chenxp.principle.ocp;

import org.apache.log4j.Logger;

public class BarChart implements IChart {

	Logger logger = Logger.getLogger(BarChart.class);
			
	@Override
	public void diplay() {
		
		logger.info("正在显示陈晓平的柱形图！");

	}

}
