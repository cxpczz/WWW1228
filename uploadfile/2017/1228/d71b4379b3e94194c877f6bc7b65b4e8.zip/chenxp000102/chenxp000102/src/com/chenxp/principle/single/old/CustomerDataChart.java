package com.chenxp.principle.single.old;

import org.apache.log4j.Logger;
import org.junit.Test;

public class CustomerDataChart {

	// 使用Log4j进行日志记录
	// Logger logger = new Logger();
	Logger logger = Logger.getLogger(CustomerDataChart.class);

	//@Test
	public void getConnection() {

		logger.info("正在获取数据库连接");

	}

	public void findCustomers() {

		// 1.连接数据库
		getConnection();

		// 2.通过Sql语句查询数据库
		logger.info("正在通过数据库查找客户");
	}

	public void createChart() {
		logger.info("正在创建图表");
	}

	@Test
	public void displayChart() {

		// 1.第一步创建图表；
		createChart();
		// 2.获取数据
		findCustomers();
		// 3.在图表上显示数据
		logger.info("正在显示图表");
	}

}
