package com.chenxp.creation.factory.p70;

//工厂（转换工具生产工厂）的抽象
public interface IConvertorCreator {

	//工厂方法（抽象），能够生产产品（协议）
	IConvertor getConvetor();	

}
