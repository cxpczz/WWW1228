package com.chenxp.principle.ocp;

import org.apache.log4j.Logger;
import org.dom4j.DocumentException;
import org.junit.Test;

import com.chenxp.util.XMLUtil;

public class ChartDisplay {

	Logger logger = Logger.getLogger(ChartDisplay.class);
	// 接口（抽象），做属性（关联）
	IChart iChart;
	
    //工具类，用于解析XML文件
    XMLUtil xMLUtil = new XMLUtil();

	// 设值注入（通过Set**方法给关联的属性赋值）
	public void SetChart(IChart ichart) {

		this.iChart = ichart;

	}

	public void display() {

		iChart.diplay();

	}
	
	//@Test
	public void test(){
		
		//生成一个饼形图对象
		//PieChart pieChart = new PieChart();
		
		BarChart barChart = new BarChart();
		
		//设值注入
		//SetChart(pieChart);
		SetChart(barChart);
		
		display();
		
	}
	
	@Test
	public void testFromXML() throws InstantiationException, IllegalAccessException, ClassNotFoundException, DocumentException{
		
		
		iChart = (IChart) xMLUtil.getObject("src/ocp.xml");	
		
		//设值注入
		SetChart(iChart);
		
		display();
		

		
	}

}
