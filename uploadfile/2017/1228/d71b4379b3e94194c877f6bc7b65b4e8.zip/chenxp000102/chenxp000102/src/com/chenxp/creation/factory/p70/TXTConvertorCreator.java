package com.chenxp.creation.factory.p70;

//具体工厂（生产TXT转换工具的工厂）
public class TXTConvertorCreator implements IConvertorCreator {

	//具体生产方法（生产TXT转换工具）
	@Override
	public IConvertor getConvetor() {
		
		//返回具体产品（TXT转换工具）
		return new TXTConvertor();
	}
}
